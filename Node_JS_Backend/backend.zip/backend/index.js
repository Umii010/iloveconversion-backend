const express = require('express');
const cors = require('cors');
const morgan = require('morgan'); 

const app = express();

app.use(cors());
app.use(express.json());

app.use(morgan(':date[clf] ":method :url" :status :response-time ms'));

const userRoutes = require('./routes/userRoutes');
app.use('/api', userRoutes);

const PORT = 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running at 192.168.18.101:${PORT}`);
    // console.log(`Server running at  192.168.0.1:${PORT}`);

});
