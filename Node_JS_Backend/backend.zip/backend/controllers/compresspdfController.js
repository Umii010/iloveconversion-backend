const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

exports.compressPdf = (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: 'No PDF uploaded' });
  }

  const inputPath = req.file.path;
  const originalFileName = req.file.originalname;
  const originalSize = fs.statSync(inputPath).size; 
  const outputPath = path.join('uploads', `compressed-${Date.now()}.pdf`);

  const gsCommand = `"C:\\Program Files\\gs\\gs10.06.0\\bin\\gswin64c.exe" -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dPDFSETTINGS=/ebook -dNOPAUSE -dQUIET -dBATCH -sOutputFile="${outputPath}" "${inputPath}"`;

  exec(gsCommand, (error, stdout, stderr) => {
    fs.unlinkSync(inputPath);

    if (error) {
      console.error('PDF compression failed', error);
      return res.status(500).json({ success: false, message: 'Compression failed' });
    }

    const compressedSize = fs.statSync(outputPath).size;

    res.set({
      'X-Original-Filename': originalFileName,
      'X-Original-Size': originalSize,
      'X-Compressed-Size': compressedSize,
    });

    res.download(outputPath, originalFileName, (err) => {
      fs.unlinkSync(outputPath);
      if (err) console.error('Error sending compressed PDF', err);
    });
  });
};
